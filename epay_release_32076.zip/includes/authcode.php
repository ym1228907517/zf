<?php
define('authcode','a6a20764dc26400bab9aea60a857c654');

?>