<?php
return [
	'app_id'			=> trim($channel['appid']),
	'api_key_live'		=> trim($channel['appkey']),
	'rsa_private_key' 	=> trim($channel['appsecret']),
];
?>