<?php
/*PAYJS支付配置*/
$config=array(
	'mchid' => $channel['appid'], //商户ID
	'key' => $channel['appkey'], //商户密钥
);
return $config;
?>